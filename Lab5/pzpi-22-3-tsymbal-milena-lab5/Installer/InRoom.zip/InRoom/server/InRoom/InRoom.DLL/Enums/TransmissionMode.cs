namespace InRoom.DLL.Enums;

public enum TransmissionMode
{
    CloseProximity,
    NonTransmissible
}