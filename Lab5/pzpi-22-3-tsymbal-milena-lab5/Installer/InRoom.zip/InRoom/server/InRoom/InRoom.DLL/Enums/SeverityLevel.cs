namespace InRoom.DLL.Enums;

public enum SeverityLevel
{
    Mild, 
    Moderate, 
    Severe
}