namespace InRoom.DLL.Enums;

public enum AccessLevels
{
    Open, 
    AdminOnly 
}