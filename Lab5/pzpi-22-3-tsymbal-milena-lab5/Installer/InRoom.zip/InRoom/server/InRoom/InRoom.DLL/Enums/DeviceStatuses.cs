namespace InRoom.DLL.Enums;

public enum DeviceStatuses
{
    Active, 
    Inactive,
    Error
}