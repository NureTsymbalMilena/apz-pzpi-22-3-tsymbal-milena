namespace InRoom.DLL.Enums;

public enum Roles
{
    User,
    PlatformAdmin,
    SystemAdmin, 
    DatabaseAdmin,
    HospitalAdmin,
}