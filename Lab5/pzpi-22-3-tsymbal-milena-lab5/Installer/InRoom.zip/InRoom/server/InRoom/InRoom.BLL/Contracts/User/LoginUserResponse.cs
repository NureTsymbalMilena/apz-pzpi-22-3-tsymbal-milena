using InRoom.DLL.Enums;

namespace InRoom.BLL.Contracts.User;

public class LoginUserResponse
{
    public string AccessToken { get; set; }
    public string RefreshToken { get; set; }
    public Guid UserId { get; set; }
    public Roles Role { get; set; }
}