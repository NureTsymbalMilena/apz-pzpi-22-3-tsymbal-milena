namespace InRoom.BLL.Contracts.User;
using InRoom.DLL.Models;

public class UsersInZoneResponse
{
    public List<UserLocation> Users { get; set; }
}