namespace InRoom.BLL.Contracts.User;
using InRoom.DLL.Models;

public class EpidemiologicalRiskAnalysisResponse
{
    public string Name { get; set; }
    public string Surname { get; set; }
    public string Disease { get; set; }
    public bool IsContagious { get; set; }
    public double TotalRisk { get; set; } 
    public string RiskLevel { get; set; }
    public TimeSpan AverageContactDuration { get; set; }
    public List<ContactAnalysis> Contacts { get; set; } 
    public  List<string> PotentialDiseases { get; set; }
}

public class ContactAnalysis
{
    public string UserName { get; set; }
    public string UserSurname { get; set; }
    public string UserDisease { get; set; }
    public string RoomName { get; set; }
    public double MinDistance { get; set; }
    public DateTime ContactStartTime { get; set; }
    public DateTime? ContactEndTime { get; set; }
}
