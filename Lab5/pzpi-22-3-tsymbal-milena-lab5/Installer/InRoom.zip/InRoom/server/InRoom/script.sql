﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
CREATE TABLE [Diseases] (
    [DiseaseId] uniqueidentifier NOT NULL,
    [Name] nvarchar(max) NOT NULL,
    [SeverityLevel] int NOT NULL,
    [Contagious] bit NOT NULL,
    [ContagionRate] float NOT NULL,
    [IncubationPeriod] int NOT NULL,
    [MortalityRate] float NOT NULL,
    [TransmissionMode] int NOT NULL,
    CONSTRAINT [PK_Diseases] PRIMARY KEY ([DiseaseId])
);

CREATE TABLE [Hospitals] (
    [HospitalId] uniqueidentifier NOT NULL,
    [Name] nvarchar(max) NOT NULL,
    [Address] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_Hospitals] PRIMARY KEY ([HospitalId])
);

CREATE TABLE [Zones] (
    [ZoneId] uniqueidentifier NOT NULL,
    [HospitalId] uniqueidentifier NOT NULL,
    [Name] nvarchar(max) NOT NULL,
    [AccessLevel] int NOT NULL,
    [FloorNumber] int NOT NULL,
    [X] real NOT NULL,
    [Y] real NOT NULL,
    [Z] real NOT NULL,
    CONSTRAINT [PK_Zones] PRIMARY KEY ([ZoneId]),
    CONSTRAINT [FK_Zones_Hospitals_HospitalId] FOREIGN KEY ([HospitalId]) REFERENCES [Hospitals] ([HospitalId]) ON DELETE CASCADE
);

CREATE TABLE [Rooms] (
    [RoomId] uniqueidentifier NOT NULL,
    [ZoneId] uniqueidentifier NOT NULL,
    [Name] nvarchar(max) NOT NULL,
    [X] real NOT NULL,
    [Y] real NOT NULL,
    [Z] real NOT NULL,
    CONSTRAINT [PK_Rooms] PRIMARY KEY ([RoomId]),
    CONSTRAINT [FK_Rooms_Zones_ZoneId] FOREIGN KEY ([ZoneId]) REFERENCES [Zones] ([ZoneId]) ON DELETE CASCADE
);

CREATE TABLE [Devices] (
    [DeviceId] uniqueidentifier NOT NULL,
    [RoomId] uniqueidentifier NOT NULL,
    [Model] nvarchar(max) NOT NULL,
    [Status] int NOT NULL,
    [SignalReceivingEnabled] bit NOT NULL,
    CONSTRAINT [PK_Devices] PRIMARY KEY ([DeviceId]),
    CONSTRAINT [FK_Devices_Rooms_RoomId] FOREIGN KEY ([RoomId]) REFERENCES [Rooms] ([RoomId]) ON DELETE CASCADE
);

CREATE TABLE [Users] (
    [UserId] uniqueidentifier NOT NULL,
    [HospitalId] uniqueidentifier NOT NULL,
    [DeviceId] uniqueidentifier NULL,
    [Name] nvarchar(max) NOT NULL,
    [Surname] nvarchar(max) NOT NULL,
    [Email] nvarchar(max) NOT NULL,
    [CreatedAt] datetime2 NOT NULL,
    [Role] int NOT NULL,
    [DiseaseId] uniqueidentifier NULL,
    [Password] nvarchar(max) NOT NULL,
    [X] real NULL,
    [Y] real NULL,
    [Z] real NULL,
    CONSTRAINT [PK_Users] PRIMARY KEY ([UserId]),
    CONSTRAINT [FK_Users_Devices_DeviceId] FOREIGN KEY ([DeviceId]) REFERENCES [Devices] ([DeviceId]),
    CONSTRAINT [FK_Users_Diseases_DiseaseId] FOREIGN KEY ([DiseaseId]) REFERENCES [Diseases] ([DiseaseId]),
    CONSTRAINT [FK_Users_Hospitals_HospitalId] FOREIGN KEY ([HospitalId]) REFERENCES [Hospitals] ([HospitalId]) ON DELETE CASCADE
);

CREATE TABLE [Contacts] (
    [ContactId] uniqueidentifier NOT NULL,
    [ContactInitiatorId] uniqueidentifier NOT NULL,
    [ContactReceiverId] uniqueidentifier NOT NULL,
    [DeviceId] uniqueidentifier NOT NULL,
    [ContactStartTime] datetime2 NOT NULL,
    [ContactEndTime] datetime2 NULL,
    [MinDistance] real NOT NULL,
    CONSTRAINT [PK_Contacts] PRIMARY KEY ([ContactId]),
    CONSTRAINT [FK_Contacts_Devices_DeviceId] FOREIGN KEY ([DeviceId]) REFERENCES [Devices] ([DeviceId]),
    CONSTRAINT [FK_Contacts_Users_ContactInitiatorId] FOREIGN KEY ([ContactInitiatorId]) REFERENCES [Users] ([UserId]),
    CONSTRAINT [FK_Contacts_Users_ContactReceiverId] FOREIGN KEY ([ContactReceiverId]) REFERENCES [Users] ([UserId])
);

CREATE TABLE [Movements] (
    [MovementId] uniqueidentifier NOT NULL,
    [DeviceId] uniqueidentifier NOT NULL,
    [UserId] uniqueidentifier NOT NULL,
    [EnterTime] datetime2 NOT NULL,
    [ExitTime] datetime2 NULL,
    CONSTRAINT [PK_Movements] PRIMARY KEY ([MovementId]),
    CONSTRAINT [FK_Movements_Devices_DeviceId] FOREIGN KEY ([DeviceId]) REFERENCES [Devices] ([DeviceId]) ON DELETE CASCADE,
    CONSTRAINT [FK_Movements_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId])
);

CREATE TABLE [Notifications] (
    [NotificationId] uniqueidentifier NOT NULL,
    [UserId] uniqueidentifier NOT NULL,
    [CreatedAt] datetime2 NOT NULL,
    [Message] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_Notifications] PRIMARY KEY ([NotificationId]),
    CONSTRAINT [FK_Notifications_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE
);

CREATE INDEX [IX_Contacts_ContactInitiatorId] ON [Contacts] ([ContactInitiatorId]);

CREATE INDEX [IX_Contacts_ContactReceiverId] ON [Contacts] ([ContactReceiverId]);

CREATE INDEX [IX_Contacts_DeviceId] ON [Contacts] ([DeviceId]);

CREATE INDEX [IX_Devices_RoomId] ON [Devices] ([RoomId]);

CREATE INDEX [IX_Movements_DeviceId] ON [Movements] ([DeviceId]);

CREATE INDEX [IX_Movements_UserId] ON [Movements] ([UserId]);

CREATE INDEX [IX_Notifications_UserId] ON [Notifications] ([UserId]);

CREATE INDEX [IX_Rooms_ZoneId] ON [Rooms] ([ZoneId]);

CREATE INDEX [IX_Users_DeviceId] ON [Users] ([DeviceId]);

CREATE INDEX [IX_Users_DiseaseId] ON [Users] ([DiseaseId]);

CREATE INDEX [IX_Users_HospitalId] ON [Users] ([HospitalId]);

CREATE INDEX [IX_Zones_HospitalId] ON [Zones] ([HospitalId]);

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20241223213920_Initial', N'9.0.0');

ALTER TABLE [Zones] ADD [Height] real NOT NULL DEFAULT CAST(0 AS real);

ALTER TABLE [Zones] ADD [Length] real NOT NULL DEFAULT CAST(0 AS real);

ALTER TABLE [Zones] ADD [Width] real NOT NULL DEFAULT CAST(0 AS real);

DECLARE @var0 sysname;
SELECT @var0 = [d].[name]
FROM [sys].[default_constraints] [d]
INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Users]') AND [c].[name] = N'Z');
IF @var0 IS NOT NULL EXEC(N'ALTER TABLE [Users] DROP CONSTRAINT [' + @var0 + '];');
UPDATE [Users] SET [Z] = CAST(0 AS real) WHERE [Z] IS NULL;
ALTER TABLE [Users] ALTER COLUMN [Z] real NOT NULL;
ALTER TABLE [Users] ADD DEFAULT CAST(0 AS real) FOR [Z];

DECLARE @var1 sysname;
SELECT @var1 = [d].[name]
FROM [sys].[default_constraints] [d]
INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Users]') AND [c].[name] = N'Y');
IF @var1 IS NOT NULL EXEC(N'ALTER TABLE [Users] DROP CONSTRAINT [' + @var1 + '];');
UPDATE [Users] SET [Y] = CAST(0 AS real) WHERE [Y] IS NULL;
ALTER TABLE [Users] ALTER COLUMN [Y] real NOT NULL;
ALTER TABLE [Users] ADD DEFAULT CAST(0 AS real) FOR [Y];

DECLARE @var2 sysname;
SELECT @var2 = [d].[name]
FROM [sys].[default_constraints] [d]
INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Users]') AND [c].[name] = N'X');
IF @var2 IS NOT NULL EXEC(N'ALTER TABLE [Users] DROP CONSTRAINT [' + @var2 + '];');
UPDATE [Users] SET [X] = CAST(0 AS real) WHERE [X] IS NULL;
ALTER TABLE [Users] ALTER COLUMN [X] real NOT NULL;
ALTER TABLE [Users] ADD DEFAULT CAST(0 AS real) FOR [X];

ALTER TABLE [Rooms] ADD [Height] real NOT NULL DEFAULT CAST(0 AS real);

ALTER TABLE [Rooms] ADD [Length] real NOT NULL DEFAULT CAST(0 AS real);

ALTER TABLE [Rooms] ADD [Width] real NOT NULL DEFAULT CAST(0 AS real);

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20241224212448_AddCoordinatesToRoomAndZone', N'9.0.0');

DECLARE @var3 sysname;
SELECT @var3 = [d].[name]
FROM [sys].[default_constraints] [d]
INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Contacts]') AND [c].[name] = N'MinDistance');
IF @var3 IS NOT NULL EXEC(N'ALTER TABLE [Contacts] DROP CONSTRAINT [' + @var3 + '];');
ALTER TABLE [Contacts] ALTER COLUMN [MinDistance] float NOT NULL;

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20241226015121_ChangeMinDistanceDataType', N'9.0.0');

COMMIT;
GO

